# Weighted-ELM
Weighted ELM Codes for Binary Problems

W. Zong, G.-B. Huang, and Y. Chen, “Weighted extreme learning machine for imbalance learning,” Neurocomputing, vol. 101, pp. 229-242, 2013.
