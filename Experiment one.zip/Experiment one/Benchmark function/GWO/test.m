clc,clear
Function_name='F2';
 [lb,ub,dim,fobj]=Get_Functions_details(Function_name);
SearchAgents_no=30;
Max_iter=500;
% dim=30;
% lb=-100;
% ub=100;
% objfun=@(x)sum(x.^2);

[Alpha_scores_CGWO,Alpha_pos_CGWO]=CGWO(SearchAgents_no,Max_iter,lb,ub,dim,fobj);
% [Alpha_score,Alpha_pos,Convergence_curve]=GWO(SearchAgents_no,Max_iter,lb,ub,dim,fobj)
 a=sin(((l*pi)/Max_iter)+pi/2)+1;
%  a=2-2*((exp(1)-1)*(exp(l/Max_iter)-1));
 %w_Alpha = Alpha_score/(Alpha_score+Beta_score+Delta_score);
            %w_Beta = Beta_score/(Alpha_score+Beta_score+Delta_score);
            %w_Delta = Delta_score/(Alpha_score+Beta_score+Delta_score);
