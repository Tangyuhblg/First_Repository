function [TrainingTime, TestingTime, test_sensitivity, test_specificity, test_gmean] = Simplified_LSSVM(TrainingData_File, TestingData_File,sigma2,C)

%%%%%%%%%%% Macro definition
REGRESSION=0;
CLASSIFIER=1;

%%%%%%%%%%% Load training dataset
train_data = TrainingData_File;
T=train_data(:,1)';
P=train_data(:,2:size(train_data,2))';
clear train_data;                                   %   Release raw training data array

%%%%%%%%%%% Load testing dataset
test_data =  TestingData_File;
TV.T=test_data(:,1)';
TV.P=test_data(:,2:size(test_data,2))';
clear test_data;                                    %   Release raw testing data array

NumberofTrainingData=size(P,2);
NumberofTestingData=size(TV.P,2);
NumberofInputNeurons=size(P,1);

[x,posx] = find(T==1);
W = zeros(length(T),length(T));

for i = 1:length(T)
    if T(i) == 1
        W(i,i)= 1/length(posx);
    else
        W(i,i)= 1/(length(T)-length(posx));
    end 
end

    %%%%%%%%%%%% Preprocessing the data of classification
    sorted_target=sort(cat(2,T,TV.T),2);
    label=zeros(1,1);                               %   Find and save in 'label' class label from training and testing data sets
    label(1,1)=sorted_target(1,1);
    j=1;
    for i = 2:(NumberofTrainingData+NumberofTestingData)
        if sorted_target(1,i) ~= label(1,j)
            j=j+1;
            label(1,j) = sorted_target(1,i);
        end
    end
    number_class=j;
    NumberofOutputNeurons=number_class;
    
    %%%%%%%%%% Processing the targets of training
    temp_T=zeros(NumberofOutputNeurons, NumberofTrainingData);
    for i = 1:NumberofTrainingData
        for j = 1:number_class
            if label(1,j) == T(1,i)
                break; 
            end
        end
        temp_T(j,i)=1;
    end
    T=temp_T*2-1;

    %%%%%%%%%% Processing the targets of testing
    temp_TV_T=zeros(NumberofOutputNeurons, NumberofTestingData);
    for i = 1:NumberofTestingData
        for j = 1:number_class
            if label(1,j) == TV.T(1,i)
                break; 
            end
        end
        temp_TV_T(j,i)=1;
    end
    TV.T=temp_TV_T*2-1;
                                              %   end if of Elm_Type

%%%%%%%%%%% Calculate weights & biases
% start_time_train=cputime;
tic;
n = size(T,2);
Omega_train = kernel_matrix(P','RBF_kernel', sigma2);
OutputWeight=((W*Omega_train+speye(n)/C)\(W*T')); 

% OutputWeight=mtimesx(H,((mtimesx(H',H)+speye(n)/C)\T')); 
% OutputWeight=inv(H * H') * H * T';                         % faster implementation
% end_time_train=cputime;
% TrainingTime=end_time_train-start_time_train     ;   %   Calculate CPU time (seconds) spent for training ELM
TrainingTime=toc;
%%%%%%%%%%% Calculate the training accuracy
Y=(Omega_train * OutputWeight)';                             %   Y: the actual output of the training data

%%%%%%%%%%% Calculate the output of testing input
% start_time_test=cputime;
tic;
Omega_test = kernel_matrix(P','RBF_kernel', sigma2,TV.P');
TY=(Omega_test' * OutputWeight)';                     %   TY: the actual output of the testing data
% end_time_test=cputime;
% TestingTime=end_time_test-start_time_test      ;     %   Calculate CPU time (seconds) spent by ELM predicting the whole testing data
TestingTime=toc;

%%%%%%%%%% Calculate training & testing classification accuracy
    %MissClassificationRate_Training=0;
    %MissClassificationRate_Testing=0;

    TP=0;
    TN=0;
    FP=0;
    FN=0;
    
    for i = 1 : size(T, 2)
        [x, label_index_expected]=max(T(:,i));
        [x, label_index_actual]=max(Y(:,i));
        if label_index_expected == 1 & label_index_actual ==1
            TP = TP + 1;
        elseif label_index_expected == 1 & label_index_actual ==2
            FN = FN + 1;
        elseif label_index_expected == 2 & label_index_actual ==1
            FP = FP + 1;
        elseif label_index_expected == 2 & label_index_actual ==2
            TN = TN + 1;
        end
        %if label_index_actual~=label_index_expected
        %    MissClassificationRate_Training=MissClassificationRate_Training+1;
        %end
    end
    %TrainingAccuracy=1-MissClassificationRate_Training/size(T,2)  ;
    train_sensitivity = TP/(TP+FN);
    train_specificity = TN/(TN+FP);
    train_gmean = sqrt(train_sensitivity * train_specificity);
    
    TP=0;
    TN=0;
    FP=0;
    FN=0;
    for i = 1 : size(TV.T, 2)
        [x, label_index_expected]=max(TV.T(:,i));
        [x, label_index_actual]=max(TY(:,i));
        %if label_index_actual~=label_index_expected
        %%    MissClassificationRate_Testing=MissClassificationRate_Testing+1;
        %end
        if label_index_expected == 1 & label_index_actual ==1
            TP = TP + 1;
        elseif label_index_expected == 1 & label_index_actual ==2
            FN = FN + 1;
        elseif label_index_expected == 2 & label_index_actual ==1
            FP = FP + 1;
        elseif label_index_expected == 2 & label_index_actual ==2
            TN = TN + 1;
        end
    end
    %TestingAccuracy=1-MissClassificationRate_Testing/size(TV.T,2)  ;
    test_sensitivity = TP/(TP+FN);
    test_specificity = TN/(TN+FP);
    test_gmean = sqrt(test_sensitivity * test_specificity);
