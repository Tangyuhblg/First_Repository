function [Acc, precision, recall, G_mean, F_measure, MCC, FPR, FNR] = Calculate_index(org_data, test, forecast)
%% �ж�����͸���
n = length(test);
num1 = length(find(org_data == 1));
num2 = length(find(org_data == 2));
if num1 > num2
    Positive_class = 2;
    Negative_class = 1;
else
    Positive_class = 1;
    Negative_class = 2;
end

%% ��ʼ������ز���
TP = 0;
FN = 0;
FP = 0;
TN = 0;
for i = 1:n
    if (test(i) == Positive_class) && (forecast(i) == Positive_class)
        TP = TP + 1;
    elseif (test(i) == Positive_class) && (forecast(i) == Negative_class)
        FN = FN + 1;
    elseif (test(i) == Negative_class) && (forecast(i) == Positive_class)
        FP = FP + 1;
    else
        TN = TN + 1;
    end
end

%% ����ָ��ֵ
TPR = TP / (TP + FN);
FNR = FN / (TP + FN);
FPR = FP / (TN + FP);
TNR = TN / (TN + FP);
recall = TP / (TP + FN);
precision = TP / (TP + FP);
F_measure = 2 * precision * recall / (precision + recall);
G_mean = sqrt(TPR * TNR);
MCC = (TP * TN - FP * FN) / sqrt((TP + FP)*(TP + FN)*(TN + FP)*(TN + FN));
Acc=(TP+TN)/(TP+TN+FP+FN);

