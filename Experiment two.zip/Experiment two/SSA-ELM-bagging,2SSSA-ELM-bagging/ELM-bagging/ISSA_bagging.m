clear all 
clc
% load data.mat;
temp_data = csvread('../����/Software Defect Datasets/MORPH/velocity-1.4.csv',1,0);
% ���ɷַ�����������
disp(['���ɷַ���.......................'])
PCA_data = PCA(temp_data(:, 1:end-1));
data = rot90(fliplr([PCA_data,temp_data(:, end)]));
[M,N]=size(data);

% [train_data,val_data,test_data]=dividerand(data,0.8,0.0,0.2);
% ������֤
indices = crossvalind('Kfold', N, 5);
for j = 1:5
    disp([num2str(j), '�ۼ�����*****************************'])
    % ��ȡ��i�ݲ������ݵ������߼�ֵ
    test = (indices == j);
    train = ~test;
    train_data = data(:, train);
    test_data = data(:, test);
    
    k=0;
    kmax=M-1;
    return_label=zeros(kmax,size(test_data,2));
    return_rate=zeros(1,kmax);

    disp(['ISSA-ELM-bagging���������.......................'])
    while(1)
        k=k+1;
        %traindata=train_data(:,ceil(rand(1,500)*size(train_data,2)));
        [traindata,~,~]=dividerand(train_data,0.4,0.0,0.6);
        [return_label(k,:),return_rate(1,k)]=extreme_ISSA_classifier(traindata,test_data);
        if(k==kmax)
            final=0;
            for i=1:size(test_data,2)
                if ((size(find(return_label(:,i)==1),1)>size(find(return_label(:,i)==2),1))&&(test_data(M,i)==1))
                    final=final+1;
                    T_sim(i) = 1;
                elseif ((size(find(return_label(:,i)==1),1)<size(find(return_label(:,i)==2),1))&&(test_data(M,i)==2))
                    final=final+1;
                    T_sim(i) = 2;
                elseif ((size(find(return_label(:,i)==1),1)>size(find(return_label(:,i)==2),1))&&(test_data(M,i)==2))
                    T_sim(i) = 1;
                else
                    T_sim(i) = 2;
                end
            end
            final_rate=final/size(test_data,2);
            break;
        end
    end

    [recall, G_mean, F_measure, MCC] = Calculate_index(data(end, :), test_data(end, :), T_sim);
    disp(['ISSA-ELM-bagging���������ྫ��:', num2str(final_rate)])
    disp(['recall = ', num2str(recall)])
    disp(['G_mean = ', num2str(G_mean)])
    disp(['F_measure = ', num2str(F_measure)])
    disp(['MCC = ', num2str(MCC)])
    ISSA_bagging_result(1, j) = final_rate;
    ISSA_bagging_result(2, j) = recall;
    ISSA_bagging_result(3, j) = G_mean;
    ISSA_bagging_result(4, j) = F_measure;
    ISSA_bagging_result(5, j) = MCC;
end

disp(['������֤���չʾ��*************************'])
disp(['ISSA-ELM-bagging������׼ȷ��:', num2str(nanmean(ISSA_bagging_result(1, :)))])
disp(['recall = ', num2str(nanmean(ISSA_bagging_result(2, :)))])
disp(['G_mean = ', num2str(nanmean(ISSA_bagging_result(3, :)))])
disp(['F_measure = ', num2str(nanmean(ISSA_bagging_result(4, :)))])
disp(['MCC = ', num2str(nanmean(ISSA_bagging_result(5, :)))])

