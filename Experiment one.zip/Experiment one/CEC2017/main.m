clear all
clc

populationSize = 30; % Number of search agents
Max_iteration = 500;
pop=30;
M=500;
runs = 30;

hhh=25;                 %
a=num2str(hhh);

% ������ʹ��F2���������Ƚϲ��ȶ�
%     Function_name=strcat('F',num2str(fn));
Function_name = 'F23';  % 5   6(����) 7 8   16 17   21 
                        
[lb,ub,dim,fobj]=CEC2017(Function_name);
 %[c,d,dim,fobj]=CEC2017(Function_name);
Best_score_T = zeros(1,runs);
PO_cg_curve2 = zeros(runs,Max_iteration);
 %     Best_pos2 = zeros(1,dim);

[fMin,bestX,PSO_convergence_curve ] = PSO(pop,M,lb,ub,dim,fobj);
[fMin,bestX,GWO_convergence_curve ] = GWO(pop,M,lb,ub,dim,fobj);
[fMin,bestX,WOA_convergence_curve ] = WOA(pop,M,lb,ub,dim,fobj);
[fMin,bestX,SSA_convergence_curve ] = SSA(pop,M,lb,ub,dim,fobj);
[fMin,bestX,ISSA_convergence_curve ] = ISSA(pop,M,lb,ub,dim,fobj);

%         [Best_score_0,Best_pos,PO_cg_curve] = SSA(populationSize,Max_iteration,lb,ub,dim,fobj);
% Best_score_T(1,run) = fMin;
% %         display(['Run: ', num2str(run), '         ', 'Fitness: ', num2str(Best_score_0), '     ', 'Position:      ', num2str(Best_pos)]);
% PO_cg_curve2(run,:) = Convergence_curve;
%         Best_pos2(run,:) = Best_pos;

figure('Position',[500 500 660 290])
%Draw search space
%subplot(1,2,1);
%func_plot(Function_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])

%Draw objective space
subplot(1,2,2);
% semilogy(PSO_convergence_curve,'Color','b')
% hold on
% semilogy(GWO_convergence_curve,'Color','r')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% hold on
% semilogy(WOA_convergence_curve,'Color','g')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% hold on
semilogy(SSA_convergence_curve,'Color','m')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
hold on
semilogy(ISSA_convergence_curve,'Color','k')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');


% xlswrite('FPSO.xlsx',PSO_convergence_curve,['A',a,':SH',a])
% xlswrite('FGWO.xlsx',GWO_convergence_curve,['A',a,':SH',a])
% xlswrite('FWOA.xlsx',WOA_convergence_curve,['A',a,':SH',a])
xlswrite('F23SSA.xlsx',SSA_convergence_curve,['A',a,':SH',a])
xlswrite('F23ISSA.xlsx',ISSA_convergence_curve,['A',a,':SH',a])

axis tight
grid on
box on
%legend('PSO','GWO','WOA','SSA','ISSA','ISSA1')
legend('SSA','ISSA')
%     Best_pos2;
%Finding statistics
% Best_score_Best = min(Best_score_T);
% Best_score_Worst = max(Best_score_T);
% Best_score_Median = median(Best_score_T,2);
% Best_Score_Mean = mean(Best_score_T,2);
% Best_Score_std = std(Best_score_T);
% %Printing results
% display(['Fn = ', num2str(fn)]);
% display(['Best, Worst, Median, Mean, and Std. are as: ', num2str(Best_score_Best),'  ', ...
%     num2str(Best_score_Worst),'  ', num2str(Best_score_Median),'  ', num2str(Best_Score_Mean),'  ', num2str(Best_Score_std)]);


