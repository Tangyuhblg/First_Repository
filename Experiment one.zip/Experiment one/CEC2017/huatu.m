clear all 
clc

aa=1;
% a=xlsread('F13PSO.xlsx');
% c=xlsread('F13GWO.xlsx');
% d=xlsread('F13WOA.xlsx');
f=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\CEC2017\F24SSA.xlsx');
h=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\CEC2017\F24ISSA.xlsx');


% PSO=a(aa,:);
% PSO=PSO(1:50:500);
% 
% 
% GWO=c(aa,:);
% GWO=GWO(1:50:500);
% 
% WOA=d(aa,:);
% WOA=WOA(1:50:500);


SSA=f(aa,:);
SSA=SSA(1:50:500);

ISSA=h(aa,:);
ISSA=ISSA(1:50:500);


z=[1:50:500];

% Function_name='C01';         % ��Ҫ

%[lb,ub,dim,fobj]=cec17_func('F13'); %ʵ��

% figure('Position',[500 500 660 290])
%Draw search space
subplot(1,2,1);
% func_plot('F13');  % ʵ��
% title('Parameter space') 
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])


%figure
figure('Position',[600 600 660 290])
subplot(1,2,1);

% semilogy(z,PSO,'-o','Color','r','LineWidth',1.2);
% hold on
% semilogy(z,GWO,'-d','Color','g','LineWidth',1.2)%p
% hold on
% semilogy(z,WOA,'-*','Color','c','LineWidth',1.2)
% hold on
semilogy(z,SSA,'-x','Color','m','LineWidth',1.2)
hold on
semilogy(z,ISSA,'-+','Color','k','LineWidth',1.2)


 axis ([0 500 -inf inf ])
 %title(['F_',num2str(aa)])
 title('C08')                 % ��Ҫ
 xlabel('Iteration');
 ylabel('Best Score');        
 
 legend('SSA','2SSSA')
 
