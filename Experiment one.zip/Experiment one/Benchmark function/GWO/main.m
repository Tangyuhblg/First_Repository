clear all 
clc

SearchAgents_no=30; % Number of search agents
Max_iteration=500; % Maximum numbef of iterations
Function_name='F3'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper) @.................................
%1 3 5 6 7 8 10 12      9 11  22 23             6         4? 
%1 2 3

[lb,ub,dim,fobj]=Get_Functions_details(Function_name);
 
hhh=25;                 %..............................%....................
a=num2str(hhh);
 
%PSO_cg_curve=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); % run PSO to compare to results
[PSO_Best_score,PSO_Best_pos,PSO_cg_curve]=PSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
[WOA_Best_score,WOA_Best_pos,WOA_cg_curve]=WOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
[GWO_Best_score,GWO_Best_pos,GWO_cg_curve]=GWO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
[SSA_Best_score,SSA_Best_pos,SSA_cg_curve]=SSA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
[ISSA_Best_score,ISSA_Best_pos,ISSA_cg_curve]=ISSA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% [ISSAtwo_Best_score,ISSAtwo_Best_pos,ISSAtwo_cg_curve]=ISSAtwo(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% [ISSA1_Best_score,ISSA1_Best_pos,ISSA1_cg_curve]=ISSA1(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% [ISSA2_Best_score,ISSA2_Best_pos,ISSA2_cg_curve]=ISSA2(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% [ISSA3_Best_score,ISSA3_Best_pos,ISSA3_cg_curve]=ISSA3(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
% 

figure('Position',[500 500 660 290])
%Draw search space
subplot(1,2,1);
func_plot(Function_name);
title('Parameter space')
xlabel('x_1');
ylabel('x_2');
zlabel([Function_name,'( x_1 , x_2 )'])

%Draw objective space
subplot(1,2,2);
semilogy(PSO_cg_curve,'Color','b')
hold on
semilogy(GWO_cg_curve,'Color','r')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
hold on
semilogy(WOA_cg_curve,'Color','g')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
hold on
semilogy(SSA_cg_curve,'Color','m')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
hold on
semilogy(ISSA_cg_curve,'Color','k')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
% hold on
% semilogy(ISSAtwo_cg_curve,'Color','c')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% hold on
% semilogy(ISSA1_cg_curve,'Color','b')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% hold on
% semilogy(ISSA2_cg_curve,'Color','r')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');
% hold on
% semilogy(ISSA3_cg_curve,'Color','g')
% title('Objective space')
% xlabel('Iteration');
% ylabel('Best score obtained so far');




xlswrite('PSO.xlsx',PSO_cg_curve,['A',a,':SH',a])  %...........................
xlswrite('GWO.xlsx',GWO_cg_curve,['A',a,':SH',a])
xlswrite('WOA.xlsx',WOA_cg_curve,['A',a,':SH',a])
xlswrite('SSA.xlsx',SSA_cg_curve,['A',a,':SH',a])
xlswrite('ISSA.xlsx',ISSA_cg_curve,['A',a,':SH',a])
% xlswrite('ISSAtwo.xlsx',ISSA_cg_curve,['A',a,':SH',a])
% xlswrite('ISSA1.xlsx',ISSA1_cg_curve,['A',a,':SH',a])
% xlswrite('ISSA2.xlsx',ISSA2_cg_curve,['A',a,':SH',a])
% xlswrite('ISSA3.xlsx',ISSA3_cg_curve,['A',a,':SH',a])
% 

% GWO_ave=mean2(GWO_cg_curve);
% GWO_std=std2(GWO_cg_curve);
% PSO_ave=mean2(PSO_cg_curve);
% PSO_std=std2(PSO_cg_curve);
% SSA_ave=mean2(SSA_cg_curve);
% SSA_std=std2(SSA_cg_curve);
% WOA_ave=mean2(WOA_cg_curve);
% WOA_std=std2(WOA_cg_curve);
% ISSA_ave=mean2(ISSA_cg_curve);
% ISSA_std=std2(ISSA_cg_curve);

axis tight
grid on
box on
legend('PSO','GWO','WOA','SSA','ISSA')
%legend('SSA','ISSA','ISSAtwo','ISSA1','ISSA2','ISSA3')
