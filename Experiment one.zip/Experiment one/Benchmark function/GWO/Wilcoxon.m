clear all 
clc
b=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\����\6MiFi48lUMa4sL\F3ISSA.xlsx');
c=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\����\6MiFi48lUMa4sL\F3WOA.xlsx');
x=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\����\6MiFi48lUMa4sL\F3GWO.xlsx');
y=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\����\6MiFi48lUMa4sL\F3SSA.xlsx');
z=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\����\6MiFi48lUMa4sL\F3PSO.xlsx');

   ISSA=b(:,500); %��
   ISSA=ISSA(1:431); %��
   
   SSA=y(:,500);
   SSA=SSA(1:431);
   a=ranksum(ISSA,SSA);
   display(a);
   
   WOA=c(:,500);
   WOA=WOA(1:431);
   a1=ranksum(ISSA,WOA);
   display(a1);
   
   GWO=x(:,500);
   GWO=GWO(1:431);
   a2=ranksum(ISSA,GWO);
   display(a2);
  
   PSO=z(:,500);
   PSO=PSO(1:431);
   a3=ranksum(ISSA,PSO);
   display(a3);
   
  
   