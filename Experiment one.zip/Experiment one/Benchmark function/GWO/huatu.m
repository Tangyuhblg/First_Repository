clear all 
clc

aa=1;
a=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\Benchmark function\Convergence curve data\F1\PSO.xlsx');
c=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\Benchmark function\Convergence curve data\F1\GWO.xlsx');
d=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\Benchmark function\Convergence curve data\F1\WOA.xlsx');
f=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\Benchmark function\Convergence curve data\F1\SSA.xlsx');
h=xlsread('C:\Users\Thinker\Desktop\ISSA-ELM\code\Experiment one\Benchmark function\Convergence curve data\F1\ISSA.xlsx'); %1 3 5 6 7 8 10 12
%log=xlsread('logSSA.xlsx');
% 1 3 5 6 7 8 10 12

PSO=a(aa,:);
PSO=PSO(1:50:500);


GWO=c(aa,:);
GWO=GWO(1:50:500);

WOA=d(aa,:);
WOA=WOA(1:50:500);


SSA=f(aa,:);
SSA=SSA(1:50:500);

ISSA=h(aa,:);
ISSA=ISSA(1:50:500);

% logSSA=log(aa,:);
% logSSA=logSSA(1:50:500);

z=[1:50:500];

Function_name='F10';                                     % 想要

[lb,ub,dim,fobj]=Get_Functions_details('F10');             %实际

figure('Position',[500 500 660 290])
%Draw search space
subplot(1,2,1);
func_plot('F10');                                          % 实际
title('Parameter space') 
xlabel('x_1');
ylabel('x_2');
zlabel([Function_name,'( x_1 , x_2 )'])

%figure
figure('Position',[600 600 660 290])
subplot(1,2,1);

semilogy(z,PSO,'-o','Color','r','LineWidth',1.2);
hold on
semilogy(z,GWO,'-d','Color','g','LineWidth',1.2)%p
hold on
semilogy(z,WOA,'-*','Color','c','LineWidth',1.2)
hold on
semilogy(z,SSA,'-x','Color','m','LineWidth',1.2)
hold on
semilogy(z,ISSA,'-+','Color','k','LineWidth',1.2)

 axis ([0 500 -inf inf ])
 %title(['F_',num2str(aa)])
 title('F10')                                           % 想要
 xlabel('Iteration');
 ylabel('Best Score');        
 
 legend('PSO','GWO','WOA','SSA','2SSSA')
 
